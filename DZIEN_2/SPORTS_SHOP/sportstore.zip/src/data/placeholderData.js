export const data = {
  categories:["Sporty wodne","Piłka nożna","Szachy","Bieganie"],
  products: [
    {id:1, name:"Kajak",category:"Sporty wodne",
      description:"jednoosobowa łódka", price: 990},
    {id:2, name:"Kamizelka ratunkowa",category:"Sporty wodne",
      description:"bezpieczeństwo", price: 120},
    {id:3, name:"Czepek pływacki",category:"Sporty wodne",
      description:"ochorna włosów", price: 89},
    {id:4, name:"Piłka turniejowa",category:"Piłka nożna",
      description:"piłka z logo mistrzostw", price: 110},
    {id:5, name:"Murawa",category:"Piłka nożna",
      description:"..żeby było na czym grać", price: 330},
    {id:6, name:"koszulka",category:"Piłka nożna",
      description:"koszulka z nr 9", price: 170},
    {id:7, name:"zestaw szachów",category:"Szachy",
      description:"od czegoś trzeba zacząć", price: 200},
    {id:8, name:"czapka geniusza",category:"Szachy",
      description:"koncentruje myśli", price: 400},
    {id:9, name:"krzywe krzesło",category:"Szachy",
      description:"dekoncentuje przeciwnika", price: 600},
    {id:10, name:"buty trailowe",category:"Bieganie",
      description:"wygoda w terenie", price: 720},
    {id:11, name:"kijki",category:"Sporty wodne",
      description:"ułatwiają marsz w górach", price: 300},
    {id:12, name:"zegarek sporotowy",category:"Bieganie",
      description:"kontroluje postępy", price: 2400}
  ]
}
