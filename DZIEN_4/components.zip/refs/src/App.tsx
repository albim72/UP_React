import Focus from './components/Focus'
import Reset from './components/Input/Reset'

function App() {
  return (
    <div className="App">
      <Focus /> <br />
      <Reset />
    </div>
  )
}

export default App