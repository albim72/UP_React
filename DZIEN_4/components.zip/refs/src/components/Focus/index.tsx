import { useRef } from 'react'

const Focus = () => {
  const inputRef = useRef<any>(null)

  const handleClick = () => { 
    inputRef.current.focus()
  }

  return ( 
    <> 
      <input 
        type="text" 
        ref={inputRef} 
      /> 
      <button onClick={handleClick}>Aktywuj</button> 
    </> 
  )
}

export default Focus