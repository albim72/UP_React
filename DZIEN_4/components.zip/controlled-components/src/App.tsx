import Controlled from './components/Controlled'

function App() {
  return (
    <div className="App">
      <Controlled />
    </div>
  )
}

export default App