import Uncontrolled from './components/Uncontrolled'

function App() {
  return (
    <div className="App">
      <Uncontrolled />
    </div>
  )
}

export default App