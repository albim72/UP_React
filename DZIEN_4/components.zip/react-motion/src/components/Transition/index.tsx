import { Motion, spring } from 'react-motion'

const Transition = () => ( 
  <Motion 
    defaultStyle={{ opacity: 0.01 }} 
    style={{ opacity: spring(1) }} 
  > 
    {interpolatingStyle => ( 
      <h1 style={interpolatingStyle}>Witaj, React</h1> 
    )} 
  </Motion> 
)

export default Transition