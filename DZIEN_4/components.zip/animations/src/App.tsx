import Transition from './components/Transition'

function App() {
  return (
    <div className="App">
      <Transition />
    </div>
  )
}

export default App