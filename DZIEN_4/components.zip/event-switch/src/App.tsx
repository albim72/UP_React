import Button from './components/Button'

function App() {
  return (
    <div className="App">
      <Button />
    </div>
  )
}

export default App